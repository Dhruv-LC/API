import uvicorn
from fastapi import FastAPI, Depends, HTTPException
from sqlalchemy import create_engine, Column, Integer, String, Float, ForeignKey
from sqlalchemy.orm import sessionmaker, Session, relationship
from sqlalchemy.ext.declarative import declarative_base
from pydantic import BaseModel
from typing import List
import datetime

# SQLAlchemy database configuration
SQLALCHEMY_DATABASE_URL = "mysql+mysqlconnector://root:@localhost:3306/iccc"
engine = create_engine(SQLALCHEMY_DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


# SQLAlchemy models
class ANPR(Base):
    __tablename__ = "anpr_information"
    id = Column(Integer, primary_key=True, index=True)
    frame_number = Column(Integer)
    car_id = Column(Integer, ForeignKey('car.id'))
    car_bbox = Column(String)
    license_plate_bbox = Column(String)
    license_plate_number = Column(String)
    license_plate_score = Column(Float)

    car = relationship("Car", back_populates="anprs")


class Car(Base):
    __tablename__ = "car"
    id = Column(Integer, primary_key=True, index=True)
    # Define other fields related to Car if needed

    anprs = relationship("ANPR", back_populates="car")


# Pydantic models
class ANPRBase(BaseModel):
    frame_number: int
    car_id: int
    car_bbox: str
    license_plate_bbox: str
    license_plate_number: str
    license_plate_score: float


class ANPRCreate(ANPRBase):
    pass


class ANPROut(ANPRBase):
    id: int
    captured_at: datetime.datetime

    class Config:
        orm_mode = True


# FastAPI application
app = FastAPI()


# Dependency to get the database session
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@app.get("/anpr/{anpr_id}", response_model=ANPROut)
def read_anpr(anpr_id: int, db: Session = Depends(get_db)):
    return db.query(ANPR).filter(ANPR.id == anpr_id).first()


@app.get("/anpr/", response_model=List[ANPROut])
def read_all_anpr(db: Session = Depends(get_db)):
    return db.query(ANPR).all()


if __name__ == "__main__":
    Base.metadata.create_all(bind=engine)
    uvicorn.run(app, host="0.0.0.0", port=8000)

